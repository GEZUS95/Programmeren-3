﻿namespace assignment2
{
    public enum CardSuit
    {
        Spades, Clubs, Hearts, Diamonds
    }
}
