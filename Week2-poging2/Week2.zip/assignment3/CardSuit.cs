﻿namespace assignment3
{
    public enum CardSuit
    {
        Spades, Clubs, Hearts, Diamonds
    }
}
