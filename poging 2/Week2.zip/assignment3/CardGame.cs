﻿namespace assignment3
{
    public class CardGame
    {
        public DeckOfCards deck = new DeckOfCards();
    }
}
